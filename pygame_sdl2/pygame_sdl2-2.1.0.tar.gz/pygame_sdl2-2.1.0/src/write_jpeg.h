#ifndef WRITE_JPEG_H
#define WRITE_JPEG_H

int Pygame_SDL2_SaveJPEG(SDL_Surface *surface, const char *file, int quality);

#endif
